import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, setPersistence, browserLocalPersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAQbc1A3FdmsOHpIOGv4f5KqAhDysOHzHg",
  authDomain: "mruknowne9.firebaseapp.com",
  projectId: "mruknowne9",
  storageBucket: "mruknowne9.firebasestorage.app",
  messagingSenderId: "931587160829",
  appId: "1:931587160829:web:de8d325dd283eab8addc94",
  measurementId: "G-HL0PJCM0RW"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = typeof window !== "undefined" ? getAnalytics(app) : null;

export const auth = getAuth(app);
// Ensure persistence works well in iframes
setPersistence(auth, browserLocalPersistence).catch(console.error);

export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

export { app, analytics, signInWithPopup, signOut };
